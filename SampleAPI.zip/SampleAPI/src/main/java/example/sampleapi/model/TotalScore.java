package example.sampleapi.model;

import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;


@Getter
@Setter
@Document("scores")
public class TotalScore {

    @Id
    private String id;

    private TeamScore[] wacc;
    private TeamScore[] factory_utilization;
    private TeamScore[] scores;
    private TeamScore[] employee_engagement;
    private TeamScore[] interest_coverage;
    private TeamScore[] marketing_spend_rev;
    private TeamScore[] e_cars_sales;
    private TeamScore[] co2_penalty;
}
