package example.sampleapi.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TeamScore {

    private int team;

    private String value;

}
