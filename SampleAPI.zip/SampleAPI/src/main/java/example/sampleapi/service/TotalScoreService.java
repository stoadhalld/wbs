package example.sampleapi.service;

import example.sampleapi.model.TeamScore;
import example.sampleapi.model.TotalScore;
import example.sampleapi.repository.TotalScoresRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TotalScoreService {

    @Autowired
    private TotalScoresRepository totalScoresRepository;

    public Optional<TotalScore> getTotalScoreById(String id){

        Optional<TotalScore> totalScore = this.totalScoresRepository.findById(id);

        return totalScore;
    }


    public List<TotalScore> getAllTotalScores(){

        List<TotalScore> allTotalScores = this.totalScoresRepository.findAll();

        return allTotalScores;
    }

    public TeamScore[] getByDateAndCategory(String id, String category){

        TotalScore totalScore = getTotalScoreById(id).orElse(null);

        if(totalScore != null){
            switch(category) {
                case "wacc":
                    return totalScore.getWacc();
                case "factory_utilization":
                    return totalScore.getFactory_utilization();
                case "scores":
                    return totalScore.getScores();
                case "employee_engagement":
                    return totalScore.getEmployee_engagement();
                case "interest_coverage":
                    return totalScore.getInterest_coverage();
                case "marketing_spend_rev":
                    return totalScore.getMarketing_spend_rev();
                case "e_cars_sales":
                    return totalScore.getE_cars_sales();
                case "co2_penalty":
                    return totalScore.getCo2_penalty();
                default:
                    return null;
            }
        }
        return null;
    }

}
