package example.sampleapi.repository;

import example.sampleapi.model.TeamScore;
import example.sampleapi.model.TotalScore;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import java.util.List;

public interface TotalScoresRepository extends MongoRepository <TotalScore, String>{

    @Query("{_id : ?0}")
    List<TeamScore> getTotalScoreById(String id);

}
