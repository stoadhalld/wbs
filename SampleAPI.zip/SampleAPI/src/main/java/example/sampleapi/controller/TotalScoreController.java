package example.sampleapi.controller;

import example.sampleapi.model.TeamScore;
import example.sampleapi.model.TotalScore;
import example.sampleapi.service.TotalScoreService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author Sam Doran
 */

@Controller
@RequestMapping(value = "/")
public class TotalScoreController {

    @Autowired
    private TotalScoreService totalScoreService;
    

    @GetMapping("")
    public String getHomePage(Model model){

        List<TotalScore> totalScores = totalScoreService.getAllTotalScores();

        DateTimeFormatter dfm = DateTimeFormatter.ofPattern("dd-MM-yyyy");

        totalScores.sort(Comparator.comparing(o -> LocalDate.parse(o.getId(), dfm)));
        List<TeamScore> earliestWaccScore = Arrays.asList(totalScores.get(0).getWacc());

        earliestWaccScore.sort(Comparator.comparing(o -> o.getTeam()));

        List<String> dates = totalScores
                .stream()
                .map(TotalScore::getId)
                .collect(Collectors.toList());

        model.addAttribute("dates", dates);

        if(!totalScores.isEmpty()) {

            List<Integer> teams = earliestWaccScore
                    .stream()
                    .map(TeamScore::getTeam)
                    .collect(Collectors.toList());

            List<String> scores = earliestWaccScore
                    .stream()
                    .map(TeamScore::getValue)
                    .collect(Collectors.toList());

            model.addAttribute("earliestWaccScore", earliestWaccScore);
            model.addAttribute("scores", scores);
            model.addAttribute("teams", teams);

        }

        return("scores");
    }

    @GetMapping("/data/{date}/{category}")
    public ResponseEntity<?> getTotalScoreData(@PathVariable String date, @PathVariable String category){

            TeamScore[] teamScoresRequested = totalScoreService.getByDateAndCategory(date, category);

            List<TeamScore> sortedTeamScores = Arrays.stream(teamScoresRequested).sorted(Comparator.comparing(o -> o.getTeam())).toList();

            return ResponseEntity.ok(sortedTeamScores);

    }




}
