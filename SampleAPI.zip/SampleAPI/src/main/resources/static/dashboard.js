let myChart;

(function () {

  // Graphs
  let ctx = document.getElementById('scoreChart')
  // eslint-disable-next-line no-unused-vars
   myChart = new Chart(ctx, {
    type: "horizontalBar",
    data: {
      labels: teams,
      datasets: [{
        label: "WACC Team scores (19-06-2023)",
        data: scores,
        backgroundColor: "rgba(0,84,164,1)",
        borderWidth: 1,
      }]
    },
    options: {
        scales: {
            xAxes: [{
                display: true,
               scaleLabel: {
               display: true,
              labelString: 'Score'
                    },
                ticks: {
                    suggestedMin: 7,
                    suggestedMax: 8
                }
            }],
            yAxes: [{
            barPercentage: .5,
                display: true,
               scaleLabel: {
               display: true,
              labelString: 'Team'
                    }
            }],
    }
    }
  })
})()

let scoreDataTable = $('#score-table').DataTable( {
    data: scoreToDisplay,
    layout: {
        topStart: {
            buttons: ['copy', 'csv', 'excel', 'pdf', 'print']
        }
    },
    columns: [
        { title: 'Team',
          data: 'team' },
        { title:'Score',
          data: 'value' }
    ]
} );


$("#load-scores-btn").click(function(){

 let category = $("#sub-select").val();
 let categoryText = $("#sub-select option:selected").text();
 let date = $("#day-select").val();

 let url = '/data/' + date + '/' + category

  $.ajax({url: url, success: function(result){

    let labelText = categoryText + " Team Scores (" + date + ")";

    $("#data-header").text(labelText)

    scoreDataTable.clear();
    scoreDataTable.rows.add( result ).draw();
    updateData(myChart, result, labelText);

  }});
});

function updateData(chart, data, labelText) {

chart.data.datasets[0].data.length = 0;
chart.data.datasets[0].label = labelText;

data.forEach(score => {

chart.data.datasets[0].data.push(score.value);

});

  chart.update();
}


console.log(myChart.data);